# Basic_Structure_Android
 Basic structure using hilt and advanced kotlin concepts
Basic Structure with following concepts added :

Concepts Added in Basic Structure:
- Data Binding
- Two way binding
- ViewModels by deligation
- Preference manager
- Binding Adapter
- Base Activity
- Base fragment
- Path utils
- Date utils
- Extensions
- PermissionHelperClass
- DateUtils
- View Binding
- Hilt for Dependency injection 
- Coroutines with code flow manner
- Structure Api call generic method
