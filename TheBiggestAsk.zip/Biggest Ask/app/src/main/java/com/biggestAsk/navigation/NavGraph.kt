@file:Suppress("OPT_IN_IS_NOT_ENABLED")

package com.biggestAsk.navigation

import android.util.Log
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.biggestAsk.ui.emailVerification.EmailVerification
import com.biggestAsk.ui.introScreen.IntroScreen
import com.biggestAsk.ui.introScreen.onBoardItem
import com.biggestAsk.ui.loginScreen.LoginScreen
import com.biggestAsk.ui.paymentScreen.PaymentScreen
import com.biggestAsk.ui.questionScreen.QuestionScreen
import com.biggestAsk.ui.registerScreen.RegisterScreen
import com.biggestAsk.ui.verifyScreen.VerifyScreen
import com.google.accompanist.pager.ExperimentalPagerApi
import com.google.accompanist.pager.rememberPagerState

@OptIn(ExperimentalPagerApi::class)
@Composable
fun SetUpNavGraph(
    navHostController: NavHostController
) {
    val pagerState = rememberPagerState()
    NavHost(
        navController = navHostController,
        startDestination = Screen.Intro.route
    ) {
        composable(
            Screen.Intro.route
        ) {
            val configuration = LocalConfiguration.current
            Log.i("TAG", "${configuration.screenHeightDp}")
            if (configuration.screenHeightDp > 700) {
                IntroScreen(
                    state = pagerState,
                    items = onBoardItem,
                    scope = rememberCoroutineScope(),
                    modifier = Modifier.fillMaxWidth(),
                    modifierBox = Modifier.padding(bottom = 56.dp),
                    modifier_indicator = Modifier.padding(bottom = 80.dp),
                    modifier_img = Modifier.fillMaxHeight(0.6f),
                    navController = navHostController
                )
            } else {
                IntroScreen(
                    state = pagerState,
                    items = onBoardItem,
                    scope = rememberCoroutineScope(),
                    modifier = Modifier.fillMaxWidth(),
                    modifierBox = Modifier.padding(bottom = 50.dp),
                    modifier_indicator = Modifier.padding(bottom = 70.dp),
                    modifier_img = Modifier.fillMaxHeight(0.5f),
                    navController = navHostController
                )
            }
        }
        composable(Screen.VerifyEmail.route) {
            EmailVerification(navHostController = navHostController)
        }
        composable(
            Screen.Register.route
        ) {
            RegisterScreen(navHostController)
        }
        composable(Screen.Verify.route) {
            val configuration = LocalConfiguration.current
            if (configuration.screenHeightDp > 700) {
                VerifyScreen(
                    navHostController, modifierTimerText = Modifier
                        .wrapContentWidth(Alignment.CenterHorizontally)
                        .padding(top = 24.dp, bottom = 150.dp)
                )
            } else {
                VerifyScreen(
                    navHostController, modifierTimerText = Modifier
                        .wrapContentWidth(Alignment.CenterHorizontally)
                        .padding(top = 24.dp, bottom = 30.dp)
                )
            }

        }
        composable(
            Screen.Login.route
        ) {
            LoginScreen(navHostController = navHostController)
        }
        composable(
            Screen.PaymentScreen.route
        ) {
            PaymentScreen(navHostController = navHostController)
        }
        composable(
            Screen.QuestionScreen.route
        ) {
            QuestionScreen(navHostController = navHostController)
        }
    }
}