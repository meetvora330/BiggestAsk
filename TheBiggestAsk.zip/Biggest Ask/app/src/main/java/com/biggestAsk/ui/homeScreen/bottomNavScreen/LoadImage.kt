package com.biggestAsk.ui.homeScreen.bottomNavScreen

import android.graphics.Bitmap

data class LoadImage(
    val bitmap: Bitmap
)
