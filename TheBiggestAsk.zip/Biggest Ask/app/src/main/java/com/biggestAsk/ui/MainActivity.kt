package com.biggestAsk.ui

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.biggestAsk.navigation.SetUpNavGraph
import com.biggestAsk.ui.base.BaseActivity
import com.biggestAsk.ui.introScreen.IntroScreen
import com.biggestAsk.ui.introScreen.LockScreenOrientation
import com.biggestAsk.ui.introScreen.onBoardItem
import com.biggestAsk.ui.ui.theme.BasicStructureTheme
import com.google.accompanist.insets.ProvideWindowInsets
import com.google.accompanist.pager.ExperimentalPagerApi
import com.google.accompanist.pager.rememberPagerState


@Suppress("OPT_IN_IS_NOT_ENABLED")
class MainActivity : BaseActivity() {
    lateinit var navController: NavHostController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
        setContent {
            val focusManager = LocalFocusManager.current
            ProvideWindowInsets(
                windowInsetsAnimationsEnabled = true
            ) {
                BasicStructureTheme {
                    navController = rememberNavController()
                    LockScreenOrientation(orientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)
                    focusManager.clearFocus()
                    SetUpNavGraph(navHostController = navController)
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
@Suppress("OPT_IN_IS_NOT_ENABLED")
@OptIn(ExperimentalPagerApi::class)
fun DefaultPreview() {
    BasicStructureTheme {
        IntroScreen(
            state = rememberPagerState(),
            items = onBoardItem,
            scope = rememberCoroutineScope(),
            modifier = Modifier.fillMaxWidth(),
            modifierBox = Modifier.padding(bottom = 56.dp),
            modifier_indicator = Modifier.padding(bottom = 85.dp),
            modifier_img = Modifier.fillMaxHeight(0.6f),
            navController = rememberNavController()
        )
    }

}
