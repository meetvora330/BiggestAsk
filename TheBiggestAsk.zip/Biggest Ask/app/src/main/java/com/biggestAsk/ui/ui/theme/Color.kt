package com.biggestAsk.ui.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)
val Custom_Blue = Color(0xFF3870C9)
val CheckBox_Check = Color(0xFF0A7AFF)
val Orange = Color(0xFFFF6E3F)
val Light_Gray = Color(0xFFF4F5F6)
val ET_Bg = Color(0xFFF4F4F4)
val Text_Color = Color(0xFF9F9D9B)
val Dark_Gray = Color(0xFFC6C4C2)
val Text_Accept_Terms = Color(0xFF7F7D7C)
val Login_Sub_Tittle = Color(0xFF1B3661)
val Payment_Description = Color(0xFF9B9BA8)