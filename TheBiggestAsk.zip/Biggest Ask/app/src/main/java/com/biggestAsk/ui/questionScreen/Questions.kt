package com.biggestAsk.ui.questionScreen

data class Questions(
    val questions: String,
    var answer: String
)

val ListQuestions = mutableListOf(
    Questions(
        questions = "Are you volunteering for the program?",
        answer = "Sure"
    ),
    Questions(
        questions = "Are you volunteering for the program?",
        answer = "Yes"
    ),
    Questions(
        questions = "Are you participating in the program for the first time?",
        answer = "Sure"
    ),
    Questions(
        questions = "Are you volunteering for the program?",
        answer = "Yes"
    ),
    Questions(
        questions = "Are you participating in the program for the first time?",
        answer = "Sure"
    ),
)