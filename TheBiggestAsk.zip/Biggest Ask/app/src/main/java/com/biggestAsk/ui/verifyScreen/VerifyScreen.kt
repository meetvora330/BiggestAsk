package com.biggestAsk.ui.verifyScreen

import android.text.TextUtils
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Button
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.CenterHorizontally
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.biggestAsk.navigation.Screen
import com.biggestAsk.ui.ui.theme.Custom_Blue
import com.example.biggestAsk.R
import kotlinx.coroutines.delay
import kotlin.time.Duration.Companion.seconds

@Composable
fun VerifyScreen(navHostController: NavHostController, modifierTimerText: Modifier) {
    var otpValue by remember { mutableStateOf("") }
    var isOtpValueVerified by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current
    var ticks by remember { mutableStateOf(58) }
    LaunchedEffect(Unit) {
        while (ticks != 0) {
            delay(1.seconds)
            ticks--
        }
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 50.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Image(
            modifier = Modifier.fillMaxWidth(6f),
            painter = painterResource(id = R.drawable.img_verify_screen),
            contentDescription = "",
            contentScale = ContentScale.Fit,
        )
        Text(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp, start = 24.dp, end = 24.dp),
            text = stringResource(id = R.string.tv_text_verify_screen_tittle),
            style = MaterialTheme.typography.body2,
            fontWeight = FontWeight.W800,
            fontSize = 24.sp,
            lineHeight = 32.sp,
            textAlign = TextAlign.Center
        )
        Text(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp, start = 24.dp, end = 24.dp),
            text = stringResource(id = R.string.tv_text_verify_screen_sub_tittle),
            color = Color(0xFF75818F),
            fontStyle = FontStyle.Normal,
            fontSize = 16.sp,
            lineHeight = 24.sp,
            textAlign = TextAlign.Center
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 39.dp, start = 28.dp, end = 28.dp)
                .height(88.dp)
                .background(Color(0xFFF4F4F4), shape = RoundedCornerShape(15.dp)),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BasicTextField(
                value = otpValue,
                onValueChange = { value ->
                    if (value.length <= 4) {
                        otpValue = value.filter { it.isDigit() }
                        isOtpValueVerified = false
                    }
                },
                enabled = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Done
                ), keyboardActions = KeyboardActions(onDone = {
                    focusManager.clearFocus()
                }), textStyle = MaterialTheme.typography.body2.copy(
                    fontSize = 32.sp,
                    fontWeight = FontWeight.W400,
                    lineHeight = 40.sp
                )
            ) {
                Row(horizontalArrangement = Arrangement.SpaceAround) {
                    repeat(4) { index ->
                        Spacer(modifier = Modifier.width(2.dp))
                        CharView(
                            index = index,
                            text = otpValue,
                            charColor = Color.Black,
                            charSize = 30.sp,
                            containerSize = 40.dp,
                            charBackground = Color.Transparent,
                            password = false,
                            passwordChar = "",
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                    }
                }
            }
        }
        if (isOtpValueVerified) {
            Text(
                modifier = Modifier
                    .fillMaxWidth(),
                text = stringResource(id = R.string.verify_screen_valid_otp_text),
                color = MaterialTheme.colors.error,
                style = MaterialTheme.typography.body2.copy(
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                ),
            )
        }
        Text(
            modifier = modifierTimerText.align(CenterHorizontally),
            text = "Resend Code:0:$ticks",
            fontSize = 16.sp,
            fontStyle = FontStyle.Normal,
            color = Custom_Blue
        )
        Button(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(start = 24.dp, end = 24.dp, bottom = 10.dp),
            onClick = {
                if (TextUtils.isEmpty(otpValue) || otpValue.length < 4) {
                    isOtpValueVerified = true
                } else {
                    navHostController.popBackStack(Screen.VerifyEmail.route, true)
                    navHostController.navigate(Screen.Register.route)
                }
            },
            elevation = ButtonDefaults.elevation(
                defaultElevation = 0.dp,
                pressedElevation = 0.dp,
                disabledElevation = 0.dp,
                hoveredElevation = 0.dp,
                focusedElevation = 0.dp
            ),
            shape = RoundedCornerShape(30),
            colors = ButtonDefaults.buttonColors(
                backgroundColor = Custom_Blue,
            )
        ) {
            Text(
                text = stringResource(id = R.string.btn_text_verify_screen_continue),
                color = Color.White,
                style = MaterialTheme.typography.body2,
                fontWeight = FontWeight.W900,
                fontSize = 16.sp
            )
        }
    }
}

@Composable
private fun CharView(
    index: Int,
    text: String,
    charColor: Color,
    charSize: TextUnit,
    containerSize: Dp,
    charBackground: Color = Color.Transparent,
    password: Boolean = false,
    passwordChar: String = ""
) {
    val modifier = Modifier
        .width(containerSize)
        .background(charBackground)

    Column(
        horizontalAlignment = CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        val char = when {
            index >= text.length -> "*"
            password -> passwordChar
            else -> text[index].toString()
        }
        Text(
            text = char,
            color = charColor,
            modifier = modifier.wrapContentHeight(),
            style = MaterialTheme.typography.body2.copy(
                fontSize = 30.sp,
                fontWeight = FontWeight.W400,
                lineHeight = 40.sp
            ),
            fontSize = charSize,
            textAlign = TextAlign.Center,
        )

    }
}


@Preview(showBackground = true, showSystemUi = true)
@Composable
fun VerifyScreenPreview() {
    VerifyScreen(rememberNavController(), modifierTimerText = Modifier)
}