package com.biggestAsk.navigation

sealed class Screen(val route: String) {
    object Intro : Screen(route = "intro_screen")
    object VerifyEmail : Screen(route = "verify_email")
    object Register : Screen(route = "register_screen")
    object Verify : Screen(route = "verify_screen")
    object Login : Screen(route = "login_screen")
    object PaymentScreen : Screen(route = "payment_screen")
    object QuestionScreen : Screen(route = "question_screen")
    object HomeScreen : Screen(route = "home_screen")
}
